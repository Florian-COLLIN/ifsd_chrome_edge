title = chrome.i18n.getMessage('extName');
