title = chrome.i18n.getMessage("extName");
description = chrome.i18N.getMessage("extDescription");
